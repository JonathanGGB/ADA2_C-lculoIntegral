import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def Riemann(a, b, n, l, f,functionString):

    numRange = np.arange(a, b, .01)

    y = f(numRange)

    deltax = float(b - a)/n

    sumaxi = 0.0

    d = {"i": 0, "d": 1, "m": 0.5, "t": 0.3}

    extremo = d[l[0]]

    for i in range(n):

        sumaxi += f(a + (i+extremo)*deltax)

        plt.gca().add_patch(matplotlib.patches.Rectangle((i*deltax + a,0),deltax,f(a + (i+extremo)*deltax),facecolor="mediumturquoise",edgecolor = "black"))
        
    plt.plot(numRange, y, color="crimson")

    sumaRiemann = deltax * sumaxi
    plt.title('f(x)= ' + str(functionString) + ', Intervalo: ' + '[' + str(a) + ',' + str(b) + ']', color="r")
    plt.suptitle('Suma de Riemann con ' + str(n) + ' rectángulos por ' + str(l) +  '= ' + str(sumaRiemann))
    plt.grid(color="grey")
    plt.xlabel('Realizado por: Jonathan Gregorio Gómez Benítez, LIS, Grupo A', color='r')
    print ('\n', sumaRiemann, '\n')
    

def main():
    print("\nBienvenido, el siguiente programa realiza la Suma de Riemann en un intervalo y número de rectángulos dados,\ngenera una gráfica donde puede apreciar el resultado junto a los datos ingresados.\n")
    
    print("Programa realizado por Jonathan Gregorio Gómez Benítez, LIS, Grupo A\n")

    print("Si desea ingresar una función del tipo x^n escriba x**n\n")
    
    print("Si desea ingresar una función del tipo nx escriba n*x\n")
    
    print("Si desea ingresar una función del tipo x + a escriba x + a\n")
    
    print("Si desea ingresar una función del tipo trigonométrica escriba np. seguido de la función,\npor ejemplo np.sin(x),np.cos(x),np.tan(x) donde x representa cualquier argumento\n")
    
    print("Si desea ingresar una función del tipo exponencial escriba np. seguido de la función,\npor ejemplo np.exp(x) para e^x donde x representa cualquier función\n")
    
    functionString = input("\nIngrese una función: ")

    a =int(input("\nIngresa el extremo izquierdo del intervalo (a): "))

    b = int(input("\nIngresa el extremo derecho del intervalo (b): "))

    while(a>=b):
        print("\nEl valor a debe ser menor que el valor b\n")

        a =int(input("\nIngresa el extremo izquierdo del intervalo (a): "))

        b = int(input("\nIngresa el extremo derecho del intervalo (b): "))

    n = int(input("\nIngresa el número de rectángulos a usar durante el proceso: "))

    l = input("\nEscriba derecha, izquierda, medio o tercio según el tipo de extremos que desea usar durante el proceso: ")

    while((l!="derecha" and l!="izquierda" and l!="medio" and l!="tercio")):

        print("\nPor favor, ingrese derecha, izquierda, medio o tercio")

        l = input("\nEscriba derecha, izquierda, medio o tercio según el tipo de extremos que desea usar durante el proceso: ")

    Riemann(a, b, n, l, lambda x: eval(functionString),functionString)
    plt.show()

 

if __name__ == "__main__":
    main()
    input("Presione ENTER para salir")
